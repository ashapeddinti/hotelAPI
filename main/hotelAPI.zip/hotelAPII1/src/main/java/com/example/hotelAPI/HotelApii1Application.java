package com.example.hotelAPI;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

import java.util.*;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@EnableJpaAuditing
@SpringBootApplication
public class HotelApii1Application {

	public static void main(String[] args) {
		SpringApplication.run(HotelApii1Application.class, args);
	}

}
